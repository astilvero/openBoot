//Registra el error en un archivo a través de un try...catch
const ejercicioNumero=datoNumerico=>{
    if(typeof datoNumerico==='number'){
        return 2+datoNumerico
    }
}

const datoNumerico = '234'
try {
    const data=ejercicioNumero(datoNumerico)
    console.log(data)
} catch (error) {
    console.error('error')
}