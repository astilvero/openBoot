import {suma, multiplica} from './controller.js'
import chalk from 'chalk';

const sum=suma(10,15)
console.log(chalk.green(sum))

const mult=multiplica(30,105)
console.log(chalk.green(mult))